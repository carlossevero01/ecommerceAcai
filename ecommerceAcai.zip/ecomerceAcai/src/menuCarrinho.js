import { catalogo, salvarLocalStorage, lerLocalStorage } from "./utilidades";

const idsProdutoCarrinhoComQnt = lerLocalStorage('carrinho') ?? {};

function abrirCarrinho() {
     document.getElementById("carrinho").classList.add('right-[0px]');
     document.getElementById("carrinho").classList.remove('right-[-360px]');
}
function fecharCarrinho() {
    document.getElementById("carrinho").classList.remove('right-[0px]');
    document.getElementById("carrinho").classList.add('right-[-360px]');
}
function irParaCheckout(params) {
  if(Object.keys(idsProdutoCarrinhoComQnt).length === 0){
    return;
  }
  window.location.href = window.location.origin + "/checkout.html";
}
export function inicializarCarrinho() {
    const botaoFecharCarrinho = document.getElementById("fechar-carrinho");
    const botaoAbrirCarrinho = document.getElementById("abrir-carrinho");
    const botaoIrParaCheckout = document.getElementById("finalizar-compra");
    botaoFecharCarrinho.addEventListener('click',fecharCarrinho);
    botaoAbrirCarrinho.addEventListener('click',abrirCarrinho);
    atualizarPrecoCarrinho();
    salvarLocalStorage("carrinho",idsProdutoCarrinhoComQnt);
    botaoIrParaCheckout.addEventListener("click",irParaCheckout);
  }
function incrementarQntProduto(idProduto) {
  idsProdutoCarrinhoComQnt[idProduto]++;
  salvarLocalStorage("carrinho",idsProdutoCarrinhoComQnt);
  atualizarPrecoCarrinho();
  atualizarQnt(idProduto);
}
function diminuirQntProduto(idProduto) {
  if(idsProdutoCarrinhoComQnt[idProduto] === 1){
    removerDoCarrinho(idProduto);
    return;
  }
  idsProdutoCarrinhoComQnt[idProduto]--;
  salvarLocalStorage("carrinho",idsProdutoCarrinhoComQnt);
  atualizarPrecoCarrinho();
  atualizarQnt(idProduto);
}

function removerDoCarrinho(idProduto) {
  delete idsProdutoCarrinhoComQnt[idProduto];
  salvarLocalStorage("carrinho",idsProdutoCarrinhoComQnt);
  atualizarPrecoCarrinho();
  renderizarProdutosCarrinho();
}
function atualizarQnt(idProduto) {
  document.getElementById(`quantidade-${idProduto}`).innerText = 
  idsProdutoCarrinhoComQnt[idProduto];
}
function desenharProdutosNoCarrinho(idProduto) {
  const produto = catalogo.find(p => p.id === idProduto);
    const containerProdutosCarrinho = document.getElementById("produtos-carrinho");
    const elementoArticle = document.createElement("article");
    const articleClasses = ["flex" ,"bg-zinc-700", "rounded-lg", "p-1" ,"relative"]
    
    for(const classe of articleClasses ){
      elementoArticle.classList.add(classe);
    }
    const cartaoProdutoCarrinho = `
    <img class="h-24 rounded-lg " src="./assets/img/${produto.imagem}" alt="${produto.nome}">
      <div class="p-2 flex flex-col justify-between">
        <p class="text-white text-sm">${produto.nome}</p>
        <p class="text-white text-xs">${produto.marca}</p>
        <p class="text-green-700 text-lg">$${produto.preco}</p>
      </div>
      <div class="flex text-zinc-950 items-end absolute bottom-2 right-20 text-lg">
            <button id='decrementar-produto-${produto.id}'><i class="fa-solid fa-minus"></i></button>
            <p class="ml-2" id='quantidade-${produto.id}'>${idsProdutoCarrinhoComQnt[produto.id]}</p>
            <button id='incrementar-produto-${produto.id}' class="ml-2"><i class="fa-solid fa-plus"></i></button>
      </div>
      <button id='remover-item-${produto.id}' class="rounded-lg bg-zinc-950 absolute top-2 right-2  items-center min-h-[90%] w-[50px] hover:bg-red-600"><i class="fa-solid fa-trash-can "></i></button> 
    `;
    elementoArticle.innerHTML = cartaoProdutoCarrinho;
    containerProdutosCarrinho.appendChild(elementoArticle);
    document.getElementById(`decrementar-produto-${produto.id}`).addEventListener("click", () => diminuirQntProduto(produto.id));
    document.getElementById(`incrementar-produto-${produto.id}`).addEventListener("click", () => incrementarQntProduto(produto.id));
    document.getElementById(`remover-item-${produto.id}`).addEventListener("click", () => removerDoCarrinho(produto.id));
  }
export function renderizarProdutosCarrinho(){
  const conteinerProdutosCarrinho = document.getElementById("produtos-carrinho");
    conteinerProdutosCarrinho.innerHTML= "";
  
    for(const idProduto in idsProdutoCarrinhoComQnt){
      desenharProdutosNoCarrinho(idProduto);
    }
}
export function adicionarAoCarrinho(idProduto) {
    if(idProduto in idsProdutoCarrinhoComQnt){
      incrementarQntProduto(idProduto);
      return;
    }
    idsProdutoCarrinhoComQnt[idProduto]=1;
    salvarLocalStorage("carrinho",idsProdutoCarrinhoComQnt);
    atualizarPrecoCarrinho();
    desenharProdutosNoCarrinho(idProduto);
}

export function atualizarPrecoCarrinho() {
  const precoCarrinho = document.getElementById(`preco-total`);
  let precoTotalCarrinho = 0;
  for(const idProdutoCarrinho in idsProdutoCarrinhoComQnt){
    precoTotalCarrinho += catalogo.find(p => p.id === idProdutoCarrinho).preco * idsProdutoCarrinhoComQnt[idProdutoCarrinho];
  }
  precoCarrinho.innerHTML = `Total: $${precoTotalCarrinho}`;
}