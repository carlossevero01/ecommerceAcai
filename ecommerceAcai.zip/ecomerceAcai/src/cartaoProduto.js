import { adicionarAoCarrinho } from "./menuCarrinho";
import {catalogo} from "./utilidades";  

export function renderizarCatalogo(params) {
    
    for (const produto of catalogo){
        const cartaoProduto = 
        `<div class='border-solid w-48 m-2 flex flex-col p-2 justify-between group shadow-xl shadow-zinc-600 rounded-lg ${produto.feminino ? 'feminino' : 'masculino'}' id="card-produto-${produto.id}">
            <img class="rounded-lg group-hover:scale-110 duration-500 my-3" src="./assets/img/${produto.imagem}" alt="img1">
            <p class='text-sm'>${produto.marca}</p>
            <p class='text-sm'>${produto.nome}</p>
            <p class='text-sm'>$${produto.preco}</p>
            <button id='adicionar-${produto.id}' class='bg-zinc-950 text-white hover:bg-zinc-500'>
            <i class="fa-solid fa-cart-plus"></i>
            </button>
        </div>`

    document.getElementById("container-produto").innerHTML += cartaoProduto;
    }
    for( const produto of catalogo){
        document
        .getElementById(`adicionar-${produto.id}`)
        .addEventListener('click', () => adicionarAoCarrinho(produto.id));
    };
}