const catalogoProdutos = document.getElementById("container-produto");
function exibirTodos(params) {
    const produtosEscondidos =  Array.from(catalogoProdutos.getElementsByClassName("hidden"));
    for(const produto of produtosEscondidos){
        produto.classList.remove('hidden');
    }
}
function esconderMasculinos() {
    exibirTodos();
    const produtosMasculinos = Array.from(catalogoProdutos.getElementsByClassName('masculino')); //Recuperar em formato de lista todos os objetos masculinos
    for(const produto of produtosMasculinos){
        produto.classList.add('hidden');
    }
}
function esconderFemininos() {
    exibirTodos();
    const produtosFemininos = Array.from(catalogoProdutos.getElementsByClassName('feminino')); //Recuperar em formato de lista todos os objetos masculinos
    for(const produto of produtosFemininos){
        produto.classList.add('hidden');
    }
}
export function inicializarFiltros(params) {
    document.getElementById("exibir-femininos").addEventListener("click", esconderMasculinos);
    document.getElementById("exibir-masculinos").addEventListener("click", esconderFemininos);
    document.getElementById("exibir-todos").addEventListener("click", exibirTodos);
}