import { desenharProdutosSimples, lerLocalStorage, apagarDoLocalStorage, salvarLocalStorage, catalogo } from "./src/utilidades";

function atualizarPrecoCarrinhoCheckout() {
    const idsProdutoCarrinhoComQnt = lerLocalStorage("carrinho") ?? [] ;
    const precoCarrinho = document.getElementById(`preco-total-checkout`);
    let precoTotalCheckout = 0;
    for(const idProdutoCarrinho in idsProdutoCarrinhoComQnt){
      precoTotalCheckout += catalogo.find(p => p.id === idProdutoCarrinho).preco * idsProdutoCarrinhoComQnt[idProdutoCarrinho];
    }
    precoCarrinho.innerHTML = `Total: $${precoTotalCheckout}`;
  }
function desenharProdutosCheckout(params) {
    const idsProdutoCarrinhoComQnt = lerLocalStorage("carrinho") ?? [] ;
    for(const idProduto in idsProdutoCarrinhoComQnt){
        desenharProdutosSimples(idProduto,"container-produtos-checkout",idsProdutoCarrinhoComQnt[idProduto]);
    } 
}
function finalizarCompra(evt) {
    evt.preventDefault();
    const idsProdutoCarrinhoComQnt = lerLocalStorage("carrinho") ?? [] ;
    if(Object.keys(idsProdutoCarrinhoComQnt).length === 0){
        return;
    }
    const dataAtual = new Date();
    const pedidoFeito = {
        dataPedido: dataAtual,
        pedido: idsProdutoCarrinhoComQnt
    };
    const historicoPedidos = lerLocalStorage("historico") ?? [];
    const historicoPedidosAtualizado = [pedidoFeito, ...historicoPedidos];
    salvarLocalStorage('historico',historicoPedidosAtualizado);
    apagarDoLocalStorage("carrinho");
    window.location.href = window.location.origin + '/pedidos.html';
}

desenharProdutosCheckout();
atualizarPrecoCarrinhoCheckout();
document.addEventListener('submit',(evt) => finalizarCompra(evt));